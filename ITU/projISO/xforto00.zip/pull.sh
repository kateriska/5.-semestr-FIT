# Autor - Katerina Fortova (xforto00)

cd ../..
chmod -R a+rX WWW
chmod o+x $HOME
cd WWW/ITUprojekt/
